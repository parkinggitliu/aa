function [dfseSNR,w_t,opt_delay]=dfsecolorsnr(l,h,nff,nbb,delay,Ex,noise);
% --------------------------------------------------------------
% [dfseSNR,w_t] = dfecolor(l,p,nff,nbb,delay,Ex,noise);
%
% INPUTS
% l = oversampling factor
% h = pulse response, oversampled at l (size)
% nff = number of feed-forward taps
% nbb = number of feedback taps
% delay = delay of system <= nff+length of p - 2 - nbb
% if delay = -1, then choose best delay
% Ex = average energy of signals
% noise = noise autocorrelation vector (size l*nff)
% so white noise is [1 zeros(l*nff-1)]
% NOTE: noise is assumed to be stationary
%
% OUTPUTS
% dfseSNR = equalizer SNR, unbiased in dB
% w_t = equalizer coefficients [w -b]
% opt_delay = optimal delay found if delay =-1 option used.
% otherwise, returns delay value passed to function
% created 4/96;
% ---------------------------------------------------------------
size = length(h);
nu = ceil(size/l)-1;
h = [h zeros(1,(nu+1)*l-size)];
% error check
if nff<=0
error('number of feed-forward taps > 0');
end
if delay > (nff+nu-1-nbb)
error('delay must be <= (nff+(length of p)-2-nbb)');
elseif delay < -1
error('delay must be >= -1');
elseif delay == -1
delay = 0:1:nff+nu-1-nbb;
end
%form htmp = [h_0 h_1 ... h_nu] where h_i=[h(i*l) h(i*l-1)... h((i-1)*l+1)
htmp(1:l,1) = [h(1); zeros(l-1,1)];
for i=1:nu
htmp(1:l,i+1) = conj((h(i*l+1:-1:(i-1)*l+2))');
end
%form matrix H, vector channel matrix
H = zeros(nff*l+nbb,nff+nu);
for i=1:nff,
H(((i-1)*l+1):(i*l),i:(i+nu)) = htmp;
end
%precompute Rn matrix - constant for all delays
Rn = zeros(nff*l+nbb);
Rn(1:nff*l,1:nff*l) = l*toeplitz(noise);
dfseSNR = -100;
H_init = H;
%loop over all possible delays
for d = delay,
H = H_init;
H(nff*l+1:nff*l+nbb,d+2:d+1+nbb) = eye(nbb);
%P
temp= zeros(1,nff+nu);
temp(d+1)=1;
%construct matrices
Ry = Ex*H*H' + Rn;
Rxy = Ex*temp*H';
new_w_t = Rxy*inv(Ry);
sigma_dfse = Ex - real(new_w_t*Rxy');
new_dfseSNR = 10*log10(Ex/sigma_dfse - 1);
%save setting of this delay if best performance so far
if new_dfseSNR >= dfseSNR
w_t = new_w_t;
dfseSNR = new_dfseSNR;
opt_delay = d;
end
end