%cross-check via time-domain circular conv
flen = length(ip.h1);
temp = [x(end-flen+2:end), x, x(1:flen-1)];
temp2 = conv(temp,ip.h1);
x1_sig_p = temp2(flen:flen+ip.N-1);
x1_p = x1_sig_p + n1;
max(x1_p-x1);
close all;

%% Plot time domain signals and various channel/filter responses
figure(1)
subplot(2,1,1);
nplot = [1:min(200,ip.N)];
plot(x(nplot), 'DisplayName','x'); hold on;  grid on;
plot(ysig(nplot), 'DisplayName','Signal component of y'); 
plot(y(nplot), 'DisplayName','y'); 
legend;

subplot(2,1,2);
plot(ip.f/ip.RS,20*log10(abs(H1)), 'r', 'DisplayName','H1'); hold on; grid on;
plot(ip.f/ip.RS,20*log10(abs(H2)), 'b', 'DisplayName','H2'); 
plot(ip.f/ip.RS,20*log10(abs(Hn)), 'k', 'DisplayName','Hn'); 
plot(ip.f/ip.RS,20*log10(abs(WFFE)), 'c', 'DisplayName','W-FFE-only'); 
plot(ip.f/ip.RS,20*log10(abs(WFFEDFE)), 'm', 'DisplayName','W-FFE-DFE'); 
plot(ip.f/ip.RS,20*log10(abs(WCSF)), 'g', 'DisplayName','W-CSF'); 
legend
% axis([0 1 -10 8])
% xlabel('Freq (f/RS)');
% ylabel('H(f) [dB]');
% legend;
% grid on

%% Equivalent signal and noise spectra
figure(2);
subplot(2,1,1)
Coi = get(gca,'ColorOrderIndex');
plot(ip.f(1:n_pts), 10.*log10(Sf), 'LineWidth',2, 'DisplayName', 'Sy(f)'); hold on; grid on;
set(gca,'ColorOrderIndex', Coi);
plot(ip.f(1:n_pts), 10.*log10(Nf), '--','LineWidth',2, 'DisplayName', 'Ny(f)'); hold on; grid on;
Coi = get(gca,'ColorOrderIndex');
plot(ip.f(1:n_pts), 10.*log10(SWdf), 'LineWidth',2, 'DisplayName', 'SWd(f)'); hold on; grid on;
set(gca,'ColorOrderIndex', Coi);
plot(ip.f(1:n_pts), 10.*log10(NWdf), '--','LineWidth',2, 'DisplayName', 'NWd(f)'); hold on; grid on;
title('FFE + DFE equalization')
legend;
xlabel('Freq [Hz]');
ylabel('[dB]');

subplot(2,1,2)
Coi = get(gca,'ColorOrderIndex');
plot(ip.f(1:n_pts), 10.*log10(Sf), 'LineWidth',2, 'DisplayName', 'Sy(f)'); hold on; grid on;
set(gca,'ColorOrderIndex', Coi);
plot(ip.f(1:n_pts), 10.*log10(Nf), '--','LineWidth',2, 'DisplayName', 'Ny(f)'); hold on; grid on;
Coi = get(gca,'ColorOrderIndex');
plot(ip.f(1:n_pts), 10.*log10(SCSFf), 'LineWidth',2, 'DisplayName', 'SCSF(f)'); hold on; grid on;
set(gca,'ColorOrderIndex', Coi);
plot(ip.f(1:n_pts), 10.*log10(NCSFf), '--','LineWidth',2, 'DisplayName', 'NCSF(f)'); hold on; grid on;
plot(ip.f(1:n_pts), 20.*log10(abs(Hdir(1:n_pts))), 'LineWidth',2, 'DisplayName', 'Desired Resp.(f)'); hold on; grid on;
title('CSF equalization for MLSE')
legend;
xlabel('Freq [Hz]');
ylabel('[dB]');

%% Histogram for signal and error after FFE+DFE (with ideal and actual feedback)
[hzc_ideal, BinE] = histcounts(zc_ideal_fb, ip.nbins,'Normalization','probability');
[err_ideal, BinE] = histcounts(err_ideal_fb, BinE,'Normalization','probability');
[hzc_actual, BinE] = histcounts(zc_fb, BinE,'Normalization','probability');
[err_actual, BinE] = histcounts(err_fb, BinE,'Normalization','probability');
BinC = BinE(1:end-1) + BinE(2:end)-BinE(1:end-1);
figure(4);
semilogy(BinC, hzc_ideal,'LineWidth',2, 'DisplayName','v: ideal fb'); hold on; grid on;
semilogy(BinC, err_ideal,'LineWidth',2, 'DisplayName','e: ideal fb'); hold on; grid on;
semilogy(BinC, hzc_actual,'LineWidth',2, 'DisplayName','v: actual fb'); hold on; grid on;
semilogy(BinC, err_actual,'LineWidth',2, 'DisplayName','e: actual fb'); hold on; grid on;
legend;
xlabel('value');
ylabel('Probability')
ylim([1e-6 1e-1]);
title("Histogram of signal and error after DFE with ideal and actual feedback")

%Error traces
figure(5); plot((sym_err_ideal_fb), '-x', 'linewidth', 2, 'DisplayName','DFE Error (ideal fb)'); hold on; grid on;
plot((sym_err_fb), ':x','linewidth', 2,'DisplayName', 'DFE Error (w fb)'); hold on; grid on;
plot((sym_err_FFE), '-x', 'linewidth', 2, 'DisplayName','FFE-only Error'); hold on; grid on;
xlim([1 500]);
ylim([-0.1, 1.1])
legend;

%% Signal and Noise PSD after RLS/LMS training
figure(6);
Coi = get(gca,'ColorOrderIndex');
plot(ip.f(1:n_pts), 10.*log10(Sf), 'LineWidth',2, 'DisplayName', 'Sy(f)'); hold on; grid on;
set(gca,'ColorOrderIndex', Coi);
plot(ip.f(1:n_pts), 10.*log10(Nf), '--','LineWidth',2, 'DisplayName', 'Ny(f)'); hold on; grid on;
Coi = get(gca,'ColorOrderIndex');
plot(ip.f(1:n_pts), 10.*log10(SWf), 'LineWidth',2, 'DisplayName', 'Su(f)-FFEonly'); hold on; grid on;
set(gca,'ColorOrderIndex', Coi);
plot(ip.f(1:n_pts), 10.*log10(NWf), '--','LineWidth',2, 'DisplayName', 'Nu(f)-FFEonly'); hold on; grid on;
Coi = get(gca,'ColorOrderIndex');
plot(ip.f(1:n_pts), 10.*log10(SWdf), 'LineWidth',2, 'DisplayName', sprintf('Su(f)-FFE+DFE (DFE-tap = %4.2f)',wdfe)); hold on; grid on;
set(gca,'ColorOrderIndex', Coi);
plot(ip.f(1:n_pts), 10.*log10(NWdf), '--','LineWidth',2, 'DisplayName', 'Nu(f)-FFE+DFE'); hold on; grid on;
Coi = get(gca,'ColorOrderIndex');
plot(ip.f(1:n_pts), 10.*log10(SCSFf), 'LineWidth',2, 'DisplayName', sprintf('SCSF(f)-MLSE (alpha = %4.2f)',hDIR(2)/hDIR(1))); hold on; grid on;
set(gca,'ColorOrderIndex', Coi);
plot(ip.f(1:n_pts), 10.*log10(NCSFf), '--','LineWidth',2, 'DisplayName', 'NCSF(f)-MLSE'); hold on; grid on;
legend;
xlabel('Freq [Hz]');
ylabel('[dB]');
title('Signal and Noise PSD after RLS/LMS training')

%% Error cluster distribution with custom MLSE
figure(7);
semilogy(ip.burstindex,symECD_FFE./num_err_FFE, '-x','linewidth', 2, 'displayname',sprintf('FFE: SER = %3.2e',SER_FFE)); grid on; hold on;
semilogy(ip.burstindex,symECD_DFE_ideal_fb./num_err_ideal_fb, '-.o','linewidth', 2, 'displayname',sprintf('DFE ideal fb: SER = %3.2e',SER_DFE_ideal_fb)); grid on; hold on;
semilogy(ip.burstindex,symECD_DFE_fb./num_err_fb, '--v','linewidth', 2, 'displayname',sprintf('DFE w. fb: SER = %3.2e',SER_DFE_fb)); grid on; hold on;
semilogy(ip.burstindex,symECD_MLSEcustom_NW./num_err_MLSEcustom_NW, '-s','linewidth', 2, 'displayname',sprintf('NW custom MLSE: SER = %3.2e',SER_MLSEcustom_NW)); grid on; hold on;
semilogy(ip.burstindex,symECD_MLSEcustom_CSF./num_err_MLSEcustom_CSF, '-o','linewidth', 2, 'displayname',sprintf('CSF custom MLSE: SER = %3.2e',SER_MLSEcustom_CSF)); grid on; hold on;
semilogy(ip.burstindex,symECD_MLSEcustom_noFFE./num_err_MLSEcustom_noFFE, '-s','linewidth', 2, 'displayname',sprintf('no FFE %d-tap custom MLSE: SER = %3.2e',length(ip.h12),SER_MLSEcustom_noFFE)); grid on; hold on;
xlabel('burst length');
ylabel('Fraction of total errors');
legend;
title('Error cluster distribution for different equalization methods');
set(gca,'fontsize',16);
