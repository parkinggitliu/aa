%%Local function to compute histogram of burst lengths
function inner_count_hist = calcBurstLen(rand_err_vec, MAX_BURST_LENGTH)
    err_indices = find(rand_err_vec);
    tot_errs = length(err_indices);
    inner_count_hist = zeros(1,MAX_BURST_LENGTH);
    diff_idx = zeros(MAX_BURST_LENGTH, length(err_indices));
    diff_idx(1,:) = err_indices;
    loop_lim = min(MAX_BURST_LENGTH, tot_errs);
    inner_count_hist(1) = length(err_indices);
    for ii=2:loop_lim
        diff_idx(ii,:) = [err_indices(ii:end) - err_indices(1:end-ii+1), zeros(1,(ii-1))];
        eq_vec = ones(size(diff_idx(ii,:)));
        for jj=(ii):-1:2
            eq_vec = eq_vec & (diff_idx(jj,:) == (jj-1));
        end
        inner_count_hist(ii) = sum(eq_vec);
        %Each n-length has been previously counted as
        %                    %2 sequences of length (n-1).
        inner_count_hist(ii-1) = inner_count_hist(ii-1) - 2*inner_count_hist(ii); %
        %And the two n-1 length sequences have one completely
        %overlapping n-2 length sequence that needs to be added
        %back
        if(ii >= 3)
            inner_count_hist(ii-2) = inner_count_hist(ii-2) + inner_count_hist(ii);
        end
    end
end

