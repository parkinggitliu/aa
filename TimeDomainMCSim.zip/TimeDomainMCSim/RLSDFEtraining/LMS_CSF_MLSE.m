function [y, wDC, wffe, h, e] = LMS_CSF_MLSE(x,d,CSFtaps,DIRtaps,RefTap)
% x: unequalized input data at symbol rate 
% d: reference data at the symbol rate ; Note: x and d are expected to be aligned within the sapn of hte equalizer
% CSFtaps: number of channel-shortening equalizer taps
% DIRtaps: number of desired impulse response taps.
% Reftap: reference taps of CSF
% LMS_mu step size 
LMS_mu_w = 5e-3;
LMS_mu_h = 5e-3;

numRefd = length(d);
numPoints = length(x); 


% CSFtaps = 14;		% default equalizer length
% Mu = 0.001;          % iteration step size


% initialize variables
w = [];
y = [];
yhat = [];
in = []; 
e = []; % error, final result to be computed
ref=[];
ovs = 1;
w = zeros(1+CSFtaps,1);
CenterTapPos= RefTap; % if x and d are perfectly time aligned; floor(CSFtaps/2)+1 for 14 taps
w(CenterTapPos) = 1; % set to 1 if passthrough equalizer
coDC = 1;

%Desired impulse response
h = zeros(DIRtaps,1);
h(1) = 1;

m=0; %1 
l=0;

% LMS Adaptation
for n  = CSFtaps:ovs:numPoints-1 %  % ; %; % CSFtaps+5 %CSFtaps+8 %CSFtaps+8 
    m=m+1;
   
    % select part of training input
    inffe = x(1+n : -1 : 1+n-CSFtaps+1) ;
    %wDC =w(1); 
    %wffe = w(1+1:1+CSFtaps);

    in = [coDC
            inffe];

    y(m) = w'*in;

    ref = d(1+m+(CSFtaps-CenterTapPos)/ovs:-1:1+m+(CSFtaps-CenterTapPos-DIRtaps+1)/ovs);
    tr(m) = h'*ref;
    
    e(m) = y(m) - tr(m);

    %update taps
    w = w - LMS_mu_w.*e(m).*in;
    h = h + LMS_mu_h.*e(m).*ref;

    %apply norm energy constraint on target response
    h = h./(sqrt(sum(h.^2)));


    
    
%    pause
end
wDC = w(1);
wffe = w(1+1:1+CSFtaps);

% % Plot results
figure(11);
semilogy(abs(e(1:1:end)));
title(['LMS CSF Adaptation Learning Curve ']);
xlabel('Iteration Number');
ylabel('Output Estimation Error in dB');
 xlim([1 1e5]); grid on;