function [y, yDC, yffe,ydfe, wDC, wffe, wdfe, e] = RLSDFE2wDC(x,d,numTaps,nDFEtaps,RefTap,ovs)
% RLS equalizer function for a equalizer of even number of taps and
% oversampled by 2
% x: unequalized input data at the oversampled by 1p5 rate
% d: reference data at the symbol rate ; Note: x and d are expected to be aligned within the sapn of hte equalizer
% numTaps: number of equalize taps, expected to be even
% Mu step size 

numRefd = length(d);
numPoints = length(x); 


% numTaps = 14;		% default equalizer length
% Mu = 0.001;          % iteration step size


% initialize variables
w = [];
y = [];
yhat = [];
in = []; 
e = []; % error, final result to be computed
ref=[];
%nDFEtaps = 4;
w = zeros(1+numTaps+nDFEtaps,1);
CenterTapPos= RefTap; % if x and d are perfectly time aligned; floor(numTaps/2)+1 for 14 taps
w(CenterTapPos) = 0; % set to 1 if passthrough equalizer
coDC = 1;

%initial P matrix
delta = 1e2; %e2 ;		 
P = delta * eye(1+numTaps+nDFEtaps) ;
lamda =    0.99999;  %0.999 ; %
m=0; %1 
l=0;
fractoffset = 0; %-1
% LMS Adaptation
for n  = numTaps:ovs:numPoints-1 %  % ; %; % numTaps+5 %numTaps+8 %numTaps+8 
    m=m+1;
   
    % select part of training input
    inffe = x(1+n : -1 : 1+n-numTaps+1) ;
    wDC =w(1); 
    wffe = w(1+1:1+numTaps);

    yffe(m) = wffe'*inffe;

    ref = d(1+m+(numTaps-CenterTapPos)/ovs);
    indfe=d(1+m+(numTaps-CenterTapPos-1)/ovs:-1:1+m+(numTaps-CenterTapPos-nDFEtaps)/ovs);
    
    wdfe = w(1+numTaps+1:1+numTaps+nDFEtaps);
    ydfe(m)= wdfe'* indfe;
    yDC(m)=wDC*coDC;

    in = [coDC
          inffe
          indfe];

    phi = in' * P ;
    k = phi'/(lamda + phi * in ); 

    y(m)=yffe(m)+ydfe(m)+yDC(m);
    
    % compute error
    e(m) =  ref-y(m);
    % update taps
    w = w + k*e(m);
    
    % quantize filter to signed 10 bits
%     maxCoeffval = max(abs(w)); 
%     w = round(w/maxCoeffval*2^9)/((2^9)/maxCoeffval);
    
    P = ( P - k * phi ) / lamda ;
    
    
%    pause
end

% % Plot results
% figure(10);
% semilogy(abs(e(1:1:end)));
% title(['RLS Adaptation Learning Curve ']);
% xlabel('Iteration Number');
% ylabel('Output Estimation Error in dB');
 