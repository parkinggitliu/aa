function [y, wDC, wffe, e] = RLSEqwDC(x,d,numTaps,RefTap,ovs)
% RLS equalizer function for a equalizer of even number of taps and
% oversampled by 2
% x: unequalized input data at the oversampled by 1p5 rate
% d: reference data at the symbol rate ; Note: x and d are expected to be aligned within the sapn of hte equalizer
% numTaps: number of equalize taps, expected to be even
% Mu step size 

numRefd = length(d);
numPoints = length(x); 


% numTaps = 14;		% default equalizer length
% Mu = 0.001;          % iteration step size


% initialize variables
w = [];
y = [];
yhat = [];
in = []; 
e = []; % error, final result to be computed
ref=[];
w = zeros(1+numTaps,1);
CenterTapPos= RefTap; % if x and d are perfectly time aligned; floor(numTaps/2)+1 for 14 taps
w(CenterTapPos) = 0; % set to 1 if passthrough equalizer
coDC = 1;

%initial P matrix
delta = 1e2; %e2 ;		 
P = delta * eye(1+numTaps) ;
lamda = 0.99999; % 0.999 ;
m=0; %1 
l=0;
fractoffset = 0; %-1
% LMS Adaptation
for n  = numTaps:ovs:numPoints %  % ; %; % numTaps+5 %numTaps+8 %numTaps+8 
    m=m+1;
   
    % select part of training input
    inffe = x(n : -1 : n-numTaps+1); 
    
    in = [coDC
          inffe];
    wDC =w(1); 
    wffe = w(1+1:1+numTaps);
    phi = in' * P ;
    k = phi'/(lamda + phi * in ); 
    y(m) = w'*in;
    %ref(m) = d(m);
    ref(m) = d(m+(numTaps-CenterTapPos)/ovs);
    % compute error
    e(m) =  ref(m)-y(m);
    % update taps
    w = w + k*e(m);
    
    % quantize filter to signed 10 bits
%     maxCoeffval = max(abs(w)); 
%     w = round(w/maxCoeffval*2^9)/((2^9)/maxCoeffval);
    
    P = ( P - k * phi ) / lamda ;
    
    
%    pause
end

% Plot results
figure(10);
semilogy(abs(e(1:1:end)));
title(['RLS Adaptation Learning Curve ']);
xlabel('Iteration Number');
ylabel('Output Estimation Error in dB');
xlim([1 1e5]); grid on;

