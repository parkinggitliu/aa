
function [x_hat] = MLSD_eq_mod(y, hTgt, sym_levs, tblen)%, 'cont', 1, [], [], []);
%tblen currently not used
%Alphabet
M = length(sym_levs);
sym_levs = reshape(sym_levs, 1, M);%row vector
b = log2(M);
chlen = length(hTgt);
v = chlen - 1;
e = 1;

if(v>4)
    error('%d states is too many.Limit channel response',Nst);
end

Nst = M^v;

% Xk = repmat(sym_levs, 1, M^(v-1));
% 
%             %Yk = hTgt(1).*(sym_levs.') + hTgt(2).*sym_levs; %works for two
%             %taps. 
% Yk = hTgt(1).*(Xk.') + hTgt(v+1).*sym_levs;
%             %Sk = repmat([1:M],Nst,1);
% Sk = repmat([1:M].*(M.^(v-1)), Nst, 1);
% 
% %% Below scheme works for 2 and 3-taps. Verified 
% % TODO: Verify for more taps
% for ii = 1:v-1
%     for jj = 1:Nst
%         %sym_id = floor((jj-1)/(M^ii)) + 1;
%         sym_id = mod(floor((jj-1)/(M^ii)),M) + 1;
%         Yk(jj,:) = Yk(jj,:) +hTgt(ii+1).*sym_levs(sym_id);
%         Sk(jj,:) = Sk(jj,:) - M + sym_id; 
%         %Yk(((jj-1)*M+1):jj*M,1:M) = Ykprev + htgt(ii)
%     end
% 
% end

%% Below scheme verified to work for 2, 3, 4, 5 taps 
Xk = repmat(sym_levs, 1, M^(v-1));
Yk = hTgt(1).*(Xk.') + hTgt(v+1).*sym_levs;
Sk = repmat([0:M-1].*(M.^(v-1)), Nst,1);

for jj = 1:Nst
    offset = floor((jj-1)/M) + 1;
    Sk(jj,:) = Sk(jj,:) + offset;
end

for ii = 1:v-1
    for jj = 1:Nst
        sym_id = mod(floor((jj-1)/(M^ii)),M) + 1;
        Yk(jj,:) = Yk(jj,:) +hTgt(ii+1).*sym_levs(sym_id);
    end

end




x_hat = mlsd_P4(y,v,b,Sk, Yk, Xk, e);

end


% function mh = MLSD_eq(y,v,b,Sk, Yk, Xk)
%
% MLSD using VA for input trellis
% Written by Ghazi Al-Rawi
% Updated significantly by J. Cioffi, 2023
% *********************************************************************
% INPUTS
% y channel output sequence
% 1 x K complex (usually real) number for partial response
% K is number of input bits in Xk
% n x K integer if BSC with convolutional code
% v constraint length (log2 of the number of states)
% b number of bits per subsymbol
% Sk M^v x 2^b previous-state description matrix
% e.g., EPR4’s H=[1 1 -1 -1] has (binary) nextstate trellis
% nextState = [1 2; 3 4; 5 6; 7 8; 1 2; 3 4; 5 6; 7 8];
% so Sk = [1 5; 1 5; 2 6; 2 6; 3 7; 3 7; 4 8; 4 8];
% Yk M^v x 2^b noiseless 1D trellis output corresponding to Sk, so EPR4
% Yk = [0 -2; 2 0; 2 0; 4 2; -2 -4; 0 -2; 0 -2; 2 0];
% for 4-state convolutional code
% Yk= [ 0 3 ; 2 1 ; 3 0 ; 1 2]
% Xk b x 2^v input vector, so EPR4 could be
% Xk = [0 1 0 1 0 1 0 1];
% e if e=1, then euclidean distance, otherwise hamming distance (xor)
%
% OUTPUT
% mh is the detected message sequence
%
% *********************************************************************

function mh = mlsd_P4(y,v,b,Sk, Yk, Xk, e)
M = 2^b;
C = [0 1e12*ones(1, M^v-1)]; % State metric, initialized so as to start at state 0
D=[];
Paths=[];
C_next=[];
for k=1:length(y),
    i=1;
    %Branch metric computation
    for j=1:M^v,
        for b=1:M
            if e == 1
                D(i) = norm(Yk(j, b)-y(k))^2;
            else
                D(i)= sum(xor(dec2bin(Yk(j,b)),dec2bin(y(k))));
            end
            i=i+1;

        end
    end
    i=1;
    for j=1:M^v,
        minCost=1e12;
        for b=1:M
            cost = C(Sk(j, b))+D(i);
            i=i+1;
            if (cost<minCost)
                minCost = cost;
                Paths(j, k) = Sk(j, b);
            end
        end
        C_next(j)=minCost;
    end
    if (mod(k,1000)==0)
        C_next = C_next - min(C_next); % Normalization
    end
    C = C_next;
end
% Find the best survivor path at k=length(y)
[minCost, I] = min(C);
if (length(I)>1)
    warning('Warning: There are more than one path with equal cost at state k=length(y)!');
end
% We will pick the first
sp=I(1);
xh=[];
for k=length(y):-1:1,
    xh(k) = Xk(sp);
    sp = Paths(sp, k);
end
mh = xh;
end

%Function includes traceback length constraint
%tblen = 0 or inf imply full sequence processing
function mh = mlsd_P4_tb(y,v,b,Sk, Yk, Xk, e, tblen)
M = 2^b;
C = [0 1e12*ones(1, M^v-1)]; % State metric, initialized so as to start at state 0
D=[];
Paths=[];
C_next=[];
for k=1:length(y),
    i=1;
    %Branch metric computation
    for j=1:M^v,
        for b=1:M
            if e == 1
                D(i) = norm(Yk(j, b)-y(k))^2;
            else
                D(i)= sum(xor(dec2bin(Yk(j,b)),dec2bin(y(k))));
            end
            i=i+1;

        end
    end
    i=1;
    for j=1:M^v,
        minCost=1e12;
        for b=1:M
            cost = C(Sk(j, b))+D(i);
            i=i+1;
            if (cost<minCost)
                minCost = cost;
                Paths(j, k) = Sk(j, b);
            end
        end
        C_next(j)=minCost;
    end
    if (mod(k,1000)==0)
        C_next = C_next - min(C_next); % Normalization
    end
    C = C_next;
end

% Find the best survivor path at k=length(y)
[minCost, I] = min(C);
if (length(I)>1)
    warning('Warning: There are more than one path with equal cost at state k=length(y)!');
end
% We will pick the first
sp=I(1);
xh=[];
for k=length(y):-1:1,
    xh(k) = Xk(sp);
    sp = Paths(sp, k);
end
mh = xh;
end
