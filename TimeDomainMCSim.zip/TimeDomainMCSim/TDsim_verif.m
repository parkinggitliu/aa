%% This is a time domain simulator to sanitize aspects of the f-domain SNR simulator including 
% MMSE filter estimation, Salz and MFB SNR computation, MLSE equalization
%% The simulated channel is shown below
%               (x1)
% x -> [H1] -> + -> [H2] -> + -> y 
%              ^            ^
%              |            | (n2prime)
%              n1         [Hn]
%                           ^
%                           |
%                           n2
%The received signal y is equalized using various techniques
clear;
close all;
rng('default');

%% Settings
%% General
ip.RS=112e9; % symbol rate
ip.sps=1; % oversampling factor
%operate at 1 initially but design to accomodate higher values (not currently functional)
ip.Ns=2^20; % number of symbols
ip.Nlevs = 4; %2 for NRZ, 4 for PAM4

%Define channels at 1sps. Zero insertion and oversampling done
ip.h1 = [1 0.6];
ip.h2 = [1 0.4];
ip.hn = [1 0.3];
ip.norm_type = 'unitDC';%'unitEnergy'; %'unitEnergy' or 'unitDC'

%Noise variances. Both n1 and n2 are white
ip.SNRn1 = 25;%dB
ip.SNRn2 = 25;%dB

%% Rx Equalizer
ip.num_ffe_taps = 31;
ip.ffe_ref_tap = floor(ip.num_ffe_taps/2); %can also be specified as an absolute number
ip.num_dfe_taps = 1;
ip.DIRtaps = 2;% MLSE desired impulse resp taps
ip.MLSE_tblen = 21; %MLSE traceback length (default)

%% Analytical MMSE eval inputs
ip.del = -1;
%% sym error threshold
ip.eps = 0.001;
%% Histogram plotting
ip.nbins = 100;
%% Error stream analysis
ip.MaxBurstLen = 25;
%% Comms toolbox have or have not
ip.HaveCommsToolBox = 1; %Set to 0 if no access to comms toolbox.

%% End of settings --------------------------------------------

if(ip.HaveCommsToolBox == 1)
    checkTbox({"Communications Toolbox"});
else
    fprintf("Running simulation without using MathWorks Communications Toolbox\n")
end
fprintf('------------------------------------------------------------\n');
fprintf('Start MC sim with settings\n');
ip
fprintf('------------------------------------------------------------\n');

%% Key derived params
ip = derive_params(ip);

%% Signal processing
%Mapping to random symbols
symbs = ip.sym_levs(randi(ip.Nlevs,1, ip.Ns));

%transmit sequence (always unit energy - repeated levels)
x = repelem(symbs./sqrt(ip.Ex), ip.sps);
X = fft(x, ip.N);

%First block
H1 = fft(ip.h1, ip.N);
n1 = randn(1,ip.N).*sqrt(ip.sigma_sq_n1);%AWGN
N1 = fft(n1);
X1sig = X.*H1 ;
X1 = X1sig + N1;
x1sig = real(ifft(X1sig));
x1 = real(ifft(X1));

%Second block
H2 = fft(ip.h2,ip.N);
Ysig = H2.*X1sig;
ysig = real(ifft(Ysig));
Hn = fft(ip.hn,ip.N);
n2 = randn(1,ip.N).*sqrt(ip.sigma_sq_n2);%AWGN
N2 = fft(n2,ip.N);
N2p = N2.*Hn;
n2p = real(ifft(N2p));

Y = X1.*H2 + N2p;
y= real(ifft(Y));

%scale
y_sc = y - mean(y);
%y_sc = y_sc./sqrt(sum(y_sc.^2)./ip.N);
Y_sc = fft(y_sc, ip.N);

%% Now freq. domain analysis
%Signal before equalizer FFE
ip.h12 = conv(ip.h1, ip.h2);
ip.norm_sq_h12 = sum(ip.h12.^2);
H12 = fft(ip.h12, ip.N);
n_pts = ip.N/(2*ip.sps);
Sf = (abs(H12(1:n_pts)).^2);
N1f = (ip.sigma_sq_n1).*(abs(H2(1:n_pts)).^2);
N2f = (ip.sigma_sq_n2).*(abs(Hn(1:n_pts)).^2);
Nf = N1f + N2f;
SNRSalz_preFFE = 10*log10(exp( sum(log(1 + Sf./Nf))./n_pts));
SNRnom_preFFE = 10*log10(sum( Sf)./sum(Nf));

%% Analytical evaluation of MMSE solution
xh2 = xcorr(ip.h2);
lh2 = length(ip.h2);
%convert to one sided
xh2 = xh2(lh2:end);
noise_vec1 = (ip.sigma_sq_n1).*[xh2, zeros(1, ip.num_ffe_taps-lh2)];

xhn = xcorr(ip.hn);
lhn = length(ip.hn);
%convert to one sided
xhn = xhn(lhn:end);
noise_vec2 = (ip.sigma_sq_n2).*[xhn, zeros(1, ip.num_ffe_taps-lhn)];
noise_vec = noise_vec1+noise_vec2;
[SNR_FFE_MMSE,w_t,opt_delay]=dfsecolorsnr(ip.sps,ip.h12,ip.num_ffe_taps,0,ip.del,var(x),noise_vec);
[SNR_DFE_MMSE,w_t,opt_delay]=dfsecolorsnr(ip.sps,ip.h12,ip.num_ffe_taps,ip.num_dfe_taps,ip.del,var(x),noise_vec);
fprintf('pre-FFE: SDNR-nominal = %4.2f dB, SNR-Salz = %4.2f dB,  SNR-FFE-MMSE = %4.2f dB, SNR-DFE-MMSE = %4.2f dB\n', ...
       SNRnom_preFFE,SNRSalz_preFFE, SNR_FFE_MMSE, SNR_DFE_MMSE);


%% RLS training -- FFE only
%Now train the RLS equalizer: FFE only
addpath("RLSDFEtraining");
[yEq, wDC, w, eEq] = RLSEqwDC(y_sc(ip.num_ffe_taps:end-ip.num_ffe_taps).',x(ip.num_ffe_taps:end-ip.num_ffe_taps).',ip.num_ffe_taps, ip.ffe_ref_tap, ip.sps);
rmpath("RLSDFEtraining");
%Use the converged equalizer to re-equalize

SNR_eq = 10.*log10(1./var(eEq(ip.N/2:end)));
fprintf('\nFFE only: Equalized SNR after convergence = %4.2f dB\n', SNR_eq);
w = w.';
WFFE = fft(w,ip.N);
Z = Y_sc.*WFFE;
z = real(ifft(Z));
zc = circshift(z,-ip.ffe_ref_tap+1);
err = x-zc;

mu_err = mean(err);
mu_z = mean(z);
mu_x = mean(x);
Pref = var(x);
Pz = var(z);
Perr = var(err);
SNR_FFE = 10.*log10(Pref./Perr) ;
x_hat_FFE = -inf.*ones(1,ip.N);
for ii = 1:ip.N
    x_hat_FFE(ii) = slicer(zc(ii),ip.dec_thresholds, (ip.sym_levs)./sqrt(ip.Ex));
end
sym_err_FFE = (abs(x_hat_FFE - x)> ip.eps);
num_err_FFE = sum(sym_err_FFE);
%SER_FFE = mean(sym_err_FFE);
SER_FFE = num_err_FFE./length(sym_err_FFE);
symECD_FFE = calcBurstLen(sym_err_FFE, ip.MaxBurstLen);

ip.h12w = conv(ip.h12,w);
H12W = fft(ip.h12w, ip.N);
ip.norm_sq_h12w = sum(ip.h12w.^2);
ip.h2w = conv(ip.h2,w);
H2W = fft(ip.h2w, ip.N);
ip.norm_sq_h2w = sum(ip.h2w.^2);
ip.hnw = conv(ip.hn,w);
HnW = fft(ip.hnw, ip.N);
ip.norm_sq_hnw = sum(ip.hnw.^2);
SWf = (abs(H12W(1:n_pts)).^2);
N1Wf = (ip.sigma_sq_n1).*(abs(H2W(1:n_pts)).^2);
N2Wf = (ip.sigma_sq_n2).*(abs(HnW(1:n_pts)).^2);
NWf = N1Wf + N2Wf;
NWf_Alt = Nf.*abs(WFFE(1:n_pts).^2);
SNRSalz_postFFE = 10*log10(exp( sum(log(1 + SWf./NWf))./n_pts));
SNRnom_postFFE = 10*log10(sum( SWf)./sum(NWf));
fprintf('post-FFE: SNR-nominal = %4.2f dB, SNR-Salz = %4.2f dB,  SNR-FFE-Eq = %4.2f dB, SER = %4.2e\n', ...
       SNRnom_postFFE,SNRSalz_postFFE, SNR_FFE, SER_FFE);


%% RLS training -- FFE + DFE
%Now train the RLS equalizer: FFE only
addpath("RLSDFEtraining");
[yEq, yDC, yffe, ydfe, wdc, wffe, wdfe, eEq] = RLSDFE2wDC(y_sc(ip.num_ffe_taps:end-ip.num_ffe_taps).',...
    x(ip.num_ffe_taps:end-ip.num_ffe_taps).',ip.num_ffe_taps, ip.num_dfe_taps, ip.ffe_ref_tap, ip.sps);
rmpath("RLSDFEtraining");
SNR_eq = 10.*log10(1./var(eEq(ip.N/2:end)));
fprintf('\nFFE+DFE: Equalized SNR after convergence = %4.2f dB\n', SNR_eq);
%Use the converged equalizer to re-equalize
w = wffe.';
WFFEDFE = fft(w,ip.N);

Z = Y_sc.*WFFEDFE;
z = real(ifft(Z));
zc = circshift(z,-ip.ffe_ref_tap+1);
zc_nw = zc; %For later use by MLSE with noise whitening filter
hTgt = [1 -wdfe]; %For later use by MLSE with noise whitening filter
%This is the error after ffe but before dfe is applied.
err = x-zc;

%DFE output assuming ideal decision
%only verified for 1 dfe tap
ideal_fb = x.*wdfe;
zc_ideal_fb = zc + circshift(ideal_fb,+1);
err_ideal_fb = x - zc_ideal_fb;

%Sequential DFE (works only for 1 tap)
x_hat_prev = x(end);
zc_fb = -inf.*ones(1,ip.N);
x_hat_fb = -inf.*ones(1,ip.N);
x_hat_ideal_fb = -inf.*ones(1,ip.N);

for ii = 1:ip.N
    zc_fb(ii) = zc(ii) + x_hat_prev.*wdfe;
    x_hat_fb(ii) = slicer(zc_fb(ii),ip.dec_thresholds, (ip.sym_levs)./sqrt(ip.Ex));
    x_hat_prev = x_hat_fb(ii);
    x_hat_ideal_fb(ii) = slicer(zc_ideal_fb(ii),ip.dec_thresholds, (ip.sym_levs)./sqrt(ip.Ex));
end
err_fb = x - zc_fb;

sym_err_ideal_fb = (abs(x_hat_ideal_fb - x)> ip.eps);
sym_err_fb = (abs(x_hat_fb - x)> ip.eps);
num_err_ideal_fb = sum(sym_err_ideal_fb);
num_err_fb = sum(sym_err_fb);

mu_err = mean(err);
mu_z = mean(z);
mu_zc_ideal_fb = mean(zc_ideal_fb);
mu_x = mean(x);
Pref = var(x);
Pz = var(z);
Pz_ideal_fb = var(zc_ideal_fb);
Perr = var(err);
Perr_ideal_fb = var(err_ideal_fb);
SNR_DFE_ideal_fb = 10.*log10(Pref./Perr_ideal_fb) ;

Pz_fb = var(zc_fb);
Perr_fb = var(err_fb);
SNR_DFE_fb = 10.*log10(Pref./Perr_fb) ;

%SER_DFE_ideal_fb = mean(sym_err_ideal_fb);
SER_DFE_ideal_fb = sum(num_err_ideal_fb)./length(sym_err_ideal_fb);

%SER_DFE_fb = mean(sym_err_fb);
SER_DFE_fb = sum(num_err_fb)./length(sym_err_fb);

symECD_DFE_ideal_fb = calcBurstLen(sym_err_ideal_fb, ip.MaxBurstLen);
symECD_DFE_fb = calcBurstLen(sym_err_fb, ip.MaxBurstLen);


ip.h12w = conv(ip.h12,w);
H12W = fft(ip.h12w, ip.N);
ip.norm_sq_h12w = sum(ip.h12w.^2);
ip.h2w = conv(ip.h2,w);
H2W = fft(ip.h2w, ip.N);
ip.norm_sq_h2w = sum(ip.h2w.^2);
ip.hnw = conv(ip.hn,w);
HnW = fft(ip.hnw, ip.N);
ip.norm_sq_hnw = sum(ip.hnw.^2);
SWdf = (abs(H12W(1:n_pts)).^2);
N1Wdf = (ip.sigma_sq_n1).*(abs(H2W(1:n_pts)).^2);
N2Wdf = (ip.sigma_sq_n2).*(abs(HnW(1:n_pts)).^2);
NWdf = N1Wdf + N2Wdf;
NWdf_Alt = Nf.*abs(WFFEDFE(1:n_pts).^2);
SNRSalz_postDFE = 10*log10(exp( sum(log(1 + SWdf./NWdf))./n_pts));
SNRnom_postDFE = 10*log10(sum( SWdf)./sum(NWdf));
fprintf('post-FFE+DFE: SNR-nominal = %4.2f dB, SNR-Salz = %4.2f dB,\nSNR-DFE-ideal = %4.2f dB, SER-DFE-ideal = %4.2e\n', ...
       SNRnom_postDFE,SNRSalz_postDFE, SNR_DFE_ideal_fb, SER_DFE_ideal_fb);
fprintf('SNR-DFE-actual = %4.2f, SER-DFE-actual = %4.2e \n', ...
       SNR_DFE_fb,SER_DFE_fb );


%% LMS traning -- CSF for MMSE
addpath("RLSDFEtraining");
[yEq, wDC, w, hDIR, eEq] = LMS_CSF_MLSE(y_sc(ip.num_ffe_taps:end-ip.num_ffe_taps).',x(ip.num_ffe_taps:end-ip.num_ffe_taps).',ip.num_ffe_taps, ip.DIRtaps, ip.ffe_ref_tap);
rmpath("RLSDFEtraining");
%Use the converged equalizer to re-equalize

SNR_eq = 10.*log10(1./var(eEq(ip.N/2:end)));
fprintf('\nCSF FFE: Equalized SNR after convergence = %4.2f dB\n', SNR_eq);
fprintf('Desired impulse response:\t');
fprintf('%5.3f ', hDIR);
fprintf('\n');
w = w.';
WCSF = fft(w,ip.N);
Z = Y_sc.*WCSF;
z = real(ifft(Z));
zc = circshift(z,-ip.ffe_ref_tap+1);
Hdir = fft(hDIR.',ip.N);
Ydir = Hdir.*X;
ydir = real(ifft(Ydir));
err = ydir - zc;

mu_err = mean(err);
mu_z = mean(z);
mu_x = mean(x);
Pref = var(ydir);
Pz = var(z);
Perr = var(err);
SNR_CSF = 10.*log10(Pref./Perr) ;


ip.h12CSF = conv(ip.h12,w);
H12CSF = fft(ip.h12CSF, ip.N);
ip.norm_sq_h12CSF = sum(ip.h12CSF.^2);
ip.h2CSF = conv(ip.h2,w);
H2CSF = fft(ip.h2CSF, ip.N);
ip.norm_sq_h2CSF = sum(ip.h2CSF.^2);
ip.hnCSF = conv(ip.hn,w);
HnCSF = fft(ip.hnCSF, ip.N);
ip.norm_sq_hnCSF = sum(ip.hnCSF.^2);
SCSFf = (abs(H12CSF(1:n_pts)).^2);
N1CSFf = (ip.sigma_sq_n1).*(abs(H2CSF(1:n_pts)).^2);
N2CSFf = (ip.sigma_sq_n2).*(abs(HnCSF(1:n_pts)).^2);
NCSFf = N1CSFf + N2CSFf;
NCSFf_Alt = Nf.*abs(WCSF(1:n_pts).^2);
SNRSalz_postCSF = 10*log10(exp( sum(log(1 + SCSFf./NCSFf))./n_pts));
SNRnom_postCSF = 10*log10(sum( SCSFf)./sum(NCSFf));

fprintf('post-CSF: SNR-nominal = %4.2f dB, SNR-Salz = %4.2f dB,  SNR-CSF-Eq = %4.2f dB\n\n', ...
       SNRnom_postCSF,SNRSalz_postCSF, SNR_CSF);

if(ip.HaveCommsToolBox == 1)
    %% MLSE (requires comm toolbox)
    %CSF
    [x_hat_MLSE_CSF, fin_met, fin_st, fin_in] = mlseeq(zc, hDIR, ip.norm_sym_levs, ip.MLSE_tblen, 'cont', 1, [], [], []);
    sym_err_MLSE_CSF = (abs(x_hat_MLSE_CSF(ip.MLSE_tblen+1:end) - x(1:end-ip.MLSE_tblen))> ip.eps);
    tempv = sym_err_MLSE_CSF(ip.num_ffe_taps+1:end-ip.num_ffe_taps);
    num_err_MLSE_CSF = sum(tempv);
    SER_MLSE_CSF = num_err_MLSE_CSF./length(tempv);
    symECD_MLSE_CSF = calcBurstLen(sym_err_MLSE_CSF, ip.MaxBurstLen);
    fprintf("MLSE CSF SNR = %3.2f dB, SER = %4.2e\n", SNR_CSF, SER_MLSE_CSF);

    %Equivalent DFE channel
    [x_hat_MLSE_NW, fin_met, fin_st, fin_in] = mlseeq(zc_nw, hTgt, ip.norm_sym_levs, ip.MLSE_tblen, 'cont', 1, [], [], []);
    sym_err_MLSE_NW = (abs(x_hat_MLSE_NW(ip.MLSE_tblen+1:end) - x(1:end-ip.MLSE_tblen))> ip.eps);
    tempv = sym_err_MLSE_NW(ip.num_ffe_taps+1:end-ip.num_ffe_taps);
    num_err_MLSE_NW = sum(tempv);
    SER_MLSE_NW = num_err_MLSE_NW./length(tempv);
    symECD_MLSE_NW = calcBurstLen(sym_err_MLSE_NW, ip.MaxBurstLen);
    Htgt = fft(hTgt, ip.N);
    Ytgt = Htgt.*X;
    yTgt = real(ifft(Ytgt));
    err = yTgt-zc_nw;
    Pref = var(yTgt);
    Perr = var(err);
    SNR_MLSE_NW = 10.*log10(Pref/Perr);
    fprintf("MLSE Noise whitening SNR = %3.2f dB, SER = %4.2e\n", SNR_MLSE_NW, SER_MLSE_NW);

    %no FFE
    [x_hat_MLSE_noFFE, fin_met, fin_st, fin_in] = mlseeq(y, ip.h12, ip.norm_sym_levs, ip.MLSE_tblen, 'cont', 1, [], [], []);
    sym_err_MLSE_noFFE = (abs(x_hat_MLSE_noFFE(ip.MLSE_tblen+1:end) - x(1:end-ip.MLSE_tblen))> ip.eps);
    tempv = sym_err_MLSE_noFFE(ip.num_ffe_taps+1:end-ip.num_ffe_taps);
    num_err_MLSE_noFFE = sum(tempv);
    SER_MLSE_noFFE = num_err_MLSE_noFFE./length(tempv);
    symECD_MLSE_noFFE = calcBurstLen(sym_err_MLSE_noFFE, ip.MaxBurstLen);
    err = ysig-y;
    Pref = var(ysig);
    Perr = var(err);
    SNR_MLSE_noFFE = 10.*log10(Pref/Perr);
    fprintf("MLSE no-FFE SNR = %3.2f dB, SER = %4.2e\n\n", SNR_MLSE_noFFE, SER_MLSE_noFFE);

end

%% MLSE without comms toolbox (custom implementation)
%2-tap noise whitening
[x_hat_MLSEcustom_NW] = MLSD_eq_mod(zc_nw, hTgt, ip.norm_sym_levs, ip.MLSE_tblen);
%sym_err_MLSEcustom_NW = (abs(x_hat_MLSEcustom_NW(ip.MLSE_tblen+1:end) - x(1:end-ip.MLSE_tblen))> ip.eps);
sym_err_MLSEcustom_NW = (abs(x_hat_MLSEcustom_NW - x)> ip.eps);
tempv = sym_err_MLSEcustom_NW(ip.num_ffe_taps+1:end-ip.num_ffe_taps);
num_err_MLSEcustom_NW = sum(tempv);
SER_MLSEcustom_NW = num_err_MLSEcustom_NW./length(tempv);
symECD_MLSEcustom_NW = calcBurstLen(sym_err_MLSEcustom_NW, ip.MaxBurstLen);
Htgt = fft(hTgt, ip.N);
Ytgt = Htgt.*X;
yTgt = real(ifft(Ytgt));
err = yTgt-zc_nw;
Pref = var(yTgt);
Perr = var(err);
SNR_MLSEcustom_NW = 10.*log10(Pref/Perr);
fprintf("MLSE-custom Noise whitening SNR = %3.2f dB, SER = %4.2e\n", SNR_MLSEcustom_NW, SER_MLSEcustom_NW);

%2-tap CSF
[x_hat_MLSEcustom_CSF] = MLSD_eq_mod(zc, hDIR, ip.norm_sym_levs, ip.MLSE_tblen );
sym_err_MLSEcustom_CSF = (abs(x_hat_MLSEcustom_CSF - x)> ip.eps);
tempv = sym_err_MLSEcustom_CSF(ip.num_ffe_taps+1:end-ip.num_ffe_taps);
num_err_MLSEcustom_CSF = sum(tempv);
%SER_MLSEcustom_CSF = mean(sym_err_MLSEcustom_CSF(ip.num_ffe_taps+1:end-ip.num_ffe_taps));
SER_MLSEcustom_CSF = num_err_MLSEcustom_CSF./length(tempv);
symECD_MLSEcustom_CSF = calcBurstLen(sym_err_MLSEcustom_CSF, ip.MaxBurstLen);
fprintf("MLSE-custom CSF SNR = %3.2f dB, SER = %4.2e\n", SNR_CSF, SER_MLSEcustom_CSF);


%MLSE, no FFE
[x_hat_MLSEcustom_noFFE] = MLSD_eq_mod(y, ip.h12, ip.norm_sym_levs, ip.MLSE_tblen);
sym_err_MLSEcustom_noFFE = (abs(x_hat_MLSEcustom_noFFE - x)> ip.eps);
tempv = sym_err_MLSEcustom_noFFE(ip.num_ffe_taps+1:end-ip.num_ffe_taps);
num_err_MLSEcustom_noFFE = sum(tempv);
SER_MLSEcustom_noFFE = num_err_MLSEcustom_noFFE./length(tempv);
symECD_MLSEcustom_noFFE = calcBurstLen(sym_err_MLSEcustom_noFFE, ip.MaxBurstLen);
err = ysig-y;
Pref = var(ysig);
Perr = var(err);
SNR_MLSEcustom_noFFE = 10.*log10(Pref/Perr);
fprintf("MLSE-custom no-FFE SNR = %3.2f dB, SER = %4.2e\n", SNR_MLSEcustom_noFFE, SER_MLSEcustom_noFFE);

xcheck;


%implements PAM-M slicer
function sl_out = slicer(sl_in, dec_thresholds, dec_levels)
    gteq = sl_in >= [-inf, dec_thresholds];
    leq = sl_in < [dec_thresholds, +inf];
    sl_out = dec_levels(gteq&leq);
end

%Check for required Mathworks Toolboxes
function checkTbox(tbxs)
    ht = matlab.addons.installedAddons;
    for ii = 1:length(tbxs)
        indicator_vec = strcmp(tbxs{ii}, ht.Name) ;
        if ~any(indicator_vec)
            error("Specified toolbox: '%s' not Installed. Set ip.HaveCommsToolBox = 0 and rerun. Exiting !!!", tbxs{ii});
        else
            if ~ht.Enabled(find(indicator_vec))
                error("Specified toolbox: '%s' installed but not Enabled. Either enable it or set ip.HaveCommsToolBox = 0 and rerun. Exiting !!!",tbxs{ii});
            end
            fprintf("%s installed and enabled. Continuing with simulation\n", tbxs{ii});
        end
    end
end

% Derive paramters
function ip = derive_params(ip)
    ip.N=ip.Ns*ip.sps;
    ip.dt=1/(ip.sps*ip.RS);
    ip.t=0:ip.dt:(ip.N-1)*ip.dt;
    ip.df=1/ip.dt/ip.N;
    ip.f=0:ip.df:(ip.N*ip.df)-ip.df;
    
    %Normalizing channels
    switch ip.norm_type
        case 'unitDC'
            ip.h1 = ip.h1./sum(ip.h1);
            ip.h2 = ip.h2./sum(ip.h2);
            ip.hn = ip.hn./sum(ip.hn);
        case 'unitEnergy'
            ip.h1 = ip.h1./sqrt(sum(ip.h1.^2));
            ip.h2 = ip.h2./sqrt(sum(ip.h2.^2));
            ip.hn = ip.hn./sqrt(sum(ip.hn.^2));
        otherwise
            error('unknown normalization type')
    end
    ip.norm_sq_h1 = sum(ip.h1.^2);
    ip.norm_sq_h2 = sum(ip.h2.^2);
    ip.norm_sq_hn = sum(ip.hn.^2);
    
    %Oversample channels with zero insertion
    if(ip.sps>1)
        ip.h1 = reshape([ip.h1; zeros(ip.sps-1, length(ip.h1))], [1, length(ip.h1).*ip.sps]);
        ip.h2 = reshape([ip.h2; zeros(ip.sps-1, length(ip.h2))], [1, length(ip.h2).*ip.sps]);
        ip.hn = reshape([ip.hn; zeros(ip.sps-1, length(ip.hn))], [1, length(ip.hn).*ip.sps]);
    end
    
    % Alphabet +-1, +-3, ..., +-(M-1)
    ip.sym_levs = [-(ip.Nlevs-1):2:(ip.Nlevs-1)];
    ip.Ex = sum(ip.sym_levs.^2)./ip.Nlevs;
    ip.norm_sym_levs = ip.sym_levs./sqrt(ip.Ex );
    
    ip.dec_thresholds = (ip.sym_levs(2:end) + ip.sym_levs(1:end-1)) /(2.*sqrt(ip.Ex));
    
    %Noise variances (referenced to unit energy signal)
    %ip.sigma_sq_n1 = (ip.norm_sq_h1)./ (10.^(ip.SNRn1./10));
    ip.sigma_sq_n1 = 1./ (10.^(ip.SNRn1./10));
    ip.sigma_sq_n2 = 1./ (10.^(ip.SNRn2./10));
    
    ip.burstindex = [1:ip.MaxBurstLen];
end